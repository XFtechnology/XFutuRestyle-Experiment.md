package ua.xfuturerestyle.staticvr;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.VideoSize;
import androidx.media3.exoplayer.ExoPlayer;

import java.util.Locale;

/**
 * Immersive static Cardboard-style cinema, focused on Android 10 / Redmi 5.
 * Supports native fullscreen 2D duplicated per eye and actual SBS 3D video.
 */
public final class MainActivity extends Activity {
    private static final int REQUEST_VIDEO = 77;
    private static final int REQUEST_LEGACY_PROFILE = 78;
    private static final int INACTIVE = Color.rgb(18, 27, 42);
    private static final int ACCENT = Color.rgb(0, 217, 255);

    private FrameLayout root;
    private VrVideoView videoView;
    private ExoPlayer player;
    private LinearLayout overlay;
    private TextView titleText, profileText;
    private Button buttonPlay, buttonMode, buttonFit, buttonLens, buttonRoot;
    private SeekBar seekBar;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean seeking = false, overlayVisible = true, hadVideo = false;
    private boolean sbs = false, fill = true, playedBeforePause;
    private float lensStrength = 1f;
    private ViewerProfile profile;
    private Uri currentUri;
    private final Runnable syncProgress = new Runnable() {
        @Override public void run() {
            if (player != null && hadVideo) {
                long duration = player.getDuration();
                long position = player.getCurrentPosition();
                if (!seeking && duration > 0) {
                    seekBar.setProgress((int)(1000.0 * position / duration));
                }
            }
            handler.postDelayed(this, 500);
        }
    };
    private final Runnable hideControls = () -> {
        if (hadVideo && player != null && player.isPlaying()) setOverlayVisible(false);
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        immersive();

        profile = ViewerProfile.load(this);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        videoView = new VrVideoView(this);
        videoView.setViewerProfile(profile);
        root.addView(videoView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.setOnClickListener(v -> {
            if (!overlayVisible) { setOverlayVisible(true); scheduleHide(); }
            else if (hadVideo) { setOverlayVisible(false); }
        });
        createControls();
        setContentView(root);

        // Audio: honor the container's DEFAULT audio flag; if none, select the first audio.
        player = new ExoPlayer.Builder(this).build();
        player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                .setPreferredAudioLanguage(null)
                .build());
        player.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(), true);
        player.addListener(new Player.Listener() {
            @Override public void onVideoSizeChanged(@NonNull VideoSize size) {
                videoView.setVideoSize(size.width, size.height, size.pixelWidthHeightRatio);
            }
            @Override public void onIsPlayingChanged(boolean isPlaying) {
                buttonPlay.setText(isPlaying ? "❚❚ Пауза" : "▶ Пуск");
                if (isPlaying) scheduleHide();
            }
            @Override public void onPlayerError(@NonNull PlaybackException error) {
                setOverlayVisible(true);
                Toast.makeText(MainActivity.this,
                        "Не вдалося відкрити відео: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        videoView.setSurfaceReadyListener(surface -> {
            if (player != null) player.setVideoSurface(surface);
        });
        handler.post(syncProgress);
        restoreLastMovie();
        maybeRequestStoragePermission();
        handleIntent(getIntent());
        loadRootProfile(false);
    }

    private void createControls() {
        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setGravity(Gravity.CENTER_HORIZONTAL);
        overlay.setPadding(dp(12), dp(10), dp(12), dp(12));
        overlay.setBackgroundColor(0xD90A1222);
        FrameLayout.LayoutParams layout = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM);
        root.addView(overlay, layout);

        titleText = new TextView(this);
        titleText.setText("STATIC VR   •   СТАЦІОНАРНЕ VR-КІНО   •   AUDIO AUTO");
        titleText.setTextColor(ACCENT);
        titleText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleText.setTextSize(13f);
        titleText.setGravity(Gravity.CENTER);
        overlay.addView(titleText, new LinearLayout.LayoutParams(-1, dp(23)));

        profileText = new TextView(this);
        profileText.setTextSize(11f);
        profileText.setTextColor(Color.LTGRAY);
        profileText.setGravity(Gravity.CENTER);
        overlay.addView(profileText, new LinearLayout.LayoutParams(-1, dp(20)));
        updateProfileText();

        seekBar = new SeekBar(this);
        seekBar.setMax(1000);
        seekBar.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        seekBar.setThumbTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        overlay.addView(seekBar, new LinearLayout.LayoutParams(-1, dp(30)));
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar seekBar) { seeking = true; handler.removeCallbacks(hideControls); }
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                seeking = false;
                if (player != null && player.getDuration() > 0)
                    player.seekTo((long)(seekBar.getProgress() / 1000.0 * player.getDuration()));
                scheduleHide();
            }
        });

        HorizontalScrollView scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.setFillViewport(true);
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER);
        scroller.addView(buttons, new HorizontalScrollView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        overlay.addView(scroller, new LinearLayout.LayoutParams(-1, dp(48)));

        Button open = button("▣ Відкрити", buttons);
        open.setOnClickListener(v -> openFilePicker());

        buttonPlay = button("▶ Пуск", buttons);
        buttonPlay.setOnClickListener(v -> {
            if (!hadVideo) { openFilePicker(); return; }
            if (player.isPlaying()) player.pause();
            else player.play();
            scheduleHide();
        });

        buttonMode = button("2D → 2 очі", buttons);
        buttonMode.setOnClickListener(v -> {
            sbs = !sbs;
            videoView.setInputIsSbs(sbs);
            buttonMode.setText(sbs ? "3D SBS" : "2D → 2 очі");
            scheduleHide();
        });

        buttonFit = button("Заповнити", buttons);
        buttonFit.setOnClickListener(v -> {
            fill = !fill;
            videoView.setFillScreen(fill);
            buttonFit.setText(fill ? "Заповнити" : "Без обрізання");
            scheduleHide();
        });

        buttonLens = button("Лінзи 100%", buttons);
        buttonLens.setOnClickListener(v -> {
            lensStrength = lensStrength == 1f ? .65f : (lensStrength == .65f ? 0f : 1f);
            videoView.setDistortionStrength(lensStrength);
            buttonLens.setText("Лінзи " + (int)(100f * lensStrength) + "%");
            scheduleHide();
        });

        Button changeProfile = button("⚙ Профіль VR", buttons);
        changeProfile.setOnClickListener(v -> showProfileDialog());

        buttonRoot = button(isRootProfileEnabled() ? "Root авто ✓" : "Root авто", buttons);
        buttonRoot.setOnClickListener(v -> {
            if (isRootProfileEnabled()) {
                getSharedPreferences("settings", MODE_PRIVATE).edit()
                        .putBoolean("root_profile_enabled", false).apply();
                buttonRoot.setText("Root авто");
                profile = ViewerProfile.load(this);
                videoView.setViewerProfile(profile);
                updateProfileText();
            } else {
                new AlertDialog.Builder(this)
                        .setTitle("Автоімпорт через root")
                        .setMessage("Програма прочитає тільки файл калібрування з " +
                                "офіційного додатка Google Cardboard. " +
                                "Root-менеджер окремо запитає дозвіл. Продовжити?")
                        .setPositiveButton("Дозволити", (dialog, which) -> {
                            getSharedPreferences("settings", MODE_PRIVATE).edit()
                                    .putBoolean("root_profile_enabled", true)
                                    .remove("viewer_url")
                                    .apply();
                            buttonRoot.setText("Root авто ✓");
                            loadRootProfile(true);
                        })
                        .setNegativeButton("Скасувати", null)
                        .show();
            }
        });
    }

    private Button button(String label, LinearLayout parent) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(12f);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(INACTIVE));
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(40));
        params.setMargins(dp(3), 0, dp(3), 0);
        parent.addView(b, params);
        return b;
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private void setOverlayVisible(boolean show) {
        overlayVisible = show;
        overlay.setVisibility(show ? View.VISIBLE : View.GONE);
        immersive();
    }

    private void scheduleHide() {
        handler.removeCallbacks(hideControls);
        if (hadVideo && !seeking) handler.postDelayed(hideControls, 5000);
    }

    private boolean isRootProfileEnabled() {
        return getSharedPreferences("settings", MODE_PRIVATE)
                .getBoolean("root_profile_enabled", false);
    }

    private void loadRootProfile(boolean showError) {
        if (!isRootProfileEnabled()) return;
        new Thread(() -> {
            ViewerProfile found = ViewerProfile.loadCardboardWithRoot();
            runOnUiThread(() -> {
                if (!isRootProfileEnabled()) return;
                if (found != null) {
                    profile = found;
                    videoView.setViewerProfile(profile);
                    updateProfileText();
                    if (showError) Toast.makeText(this, "Профіль Google Cardboard імпортовано", Toast.LENGTH_SHORT).show();
                } else if (showError) {
                    Toast.makeText(this, "Root-профіль недоступний. Спробуй вставити QR URL.", Toast.LENGTH_LONG).show();
                }
            });
        }, "CardboardRootProfile").start();
    }

    private void updateProfileText() {
        if (profileText != null) profileText.setText(
                "Гарнітура: " + profile.name + "   •   " + profile.source + "   •   без трекінгу голови");
    }

    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("video/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES,
                new String[]{"video/*", "video/x-matroska", "video/mp4"});
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(intent, REQUEST_VIDEO); }
        catch (Exception e) { Toast.makeText(this, "Немає доступного менеджера файлів", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_VIDEO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) { }
            playUri(uri);
        }
    }

    private void playUri(Uri uri) {
        currentUri = uri;
        hadVideo = true;
        player.setMediaItem(MediaItem.fromUri(uri));
        player.prepare();
        player.play();
        getSharedPreferences("settings", MODE_PRIVATE).edit().putString("last_video", uri.toString()).apply();
        setOverlayVisible(true);
        scheduleHide();
    }

    private void restoreLastMovie() {
        String movie = getSharedPreferences("settings", MODE_PRIVATE).getString("last_video", "");
        if (movie.isEmpty()) return;
        for (android.content.UriPermission permission : getContentResolver().getPersistedUriPermissions()) {
            if (permission.isReadPermission() && movie.equals(permission.getUri().toString())) {
                playUri(permission.getUri());
                player.pause();
                return;
            }
        }
    }

    private void handleIntent(Intent intent) {
        if (intent != null && Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
            playUri(intent.getData());
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void maybeRequestStoragePermission() {
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT <= 32 &&
                checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_LEGACY_PROFILE);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                                    @NonNull int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_LEGACY_PROFILE && results.length > 0 &&
                results[0] == PackageManager.PERMISSION_GRANTED) {
            profile = ViewerProfile.load(this);
            videoView.setViewerProfile(profile);
            updateProfileText();
        }
    }

    private void showProfileDialog() {
        EditText input = new EditText(this);
        input.setText(getSharedPreferences("settings", MODE_PRIVATE).getString("viewer_url", ""));
        input.setHint("https://google.com/cardboard/cfg?p=...");
        input.setTextSize(12f);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setSelectAllOnFocus(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(12), dp(20), 0);
        TextView explanation = new TextView(this);
        explanation.setText("Спроба автоматичного читання старого профілю Cardboard. Якщо новий Cardboard зберігає QR-прив'язку приватно, встав сюди URL із QR-коду гарнітури.");
        explanation.setTextColor(Color.DKGRAY);
        explanation.setTextSize(13f);
        content.addView(explanation);
        content.addView(input);
        new AlertDialog.Builder(this)
                .setTitle("Калібрування VR-гарнітури")
                .setView(content)
                .setPositiveButton("Застосувати", (d, which) -> {
                    String url = input.getText().toString().trim();
                    try {
                        if (url.isEmpty()) {
                            getSharedPreferences("settings", MODE_PRIVATE).edit().remove("viewer_url").apply();
                            profile = ViewerProfile.load(this);
                        } else {
                            ViewerProfile imported = ViewerProfile.fromUrl(url);
                            getSharedPreferences("settings", MODE_PRIVATE).edit()
                                    .putString("viewer_url", url)
                                    .putBoolean("root_profile_enabled", false).apply();
                            if (buttonRoot != null) buttonRoot.setText("Root авто");
                            profile = imported;
                        }
                        videoView.setViewerProfile(profile);
                        updateProfileText();
                        Toast.makeText(this, "VR профіль застосовано", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(this, "Профіль не прийнято: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                })
                .setNeutralButton("Автовизначення", (d, which) -> {
                    getSharedPreferences("settings", MODE_PRIVATE).edit().remove("viewer_url").apply();
                    profile = ViewerProfile.load(this);
                    videoView.setViewerProfile(profile);
                    updateProfileText();
                    loadRootProfile(false);
                })
                .setNegativeButton("Скасувати", null)
                .show();
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) immersive();
    }

    @Override protected void onPause() {
        playedBeforePause = player != null && player.isPlaying();
        if (player != null) player.pause();
        if (videoView != null) videoView.onPause();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        immersive();
        if (videoView != null) videoView.onResume();
        // Do not auto-resume on return from file picker: user can press play.
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.clearVideoSurface();
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
