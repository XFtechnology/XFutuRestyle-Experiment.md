package ua.xfuturerestyle.staticvr;

import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;

import java.io.DataInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;
import java.io.File;
import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Small dependency-free Cardboard DeviceParams protocol buffer decoder.
 * Android 10 may expose the legacy shared Cardboard/current_device_params file.
 * Modern Cardboard releases use app-private storage, which another normal app CANNOT read.
 */
public final class ViewerProfile {
    public final float screenToLensMeters;
    public final float interLensMeters;
    public final float trayMeters;
    public final float k1;
    public final float k2;
    public final int verticalAlignment;
    public final String name;
    public final String source;

    private ViewerProfile(float screenToLensMeters, float interLensMeters, float trayMeters,
                          float k1, float k2, int verticalAlignment, String name, String source) {
        this.screenToLensMeters = screenToLensMeters;
        this.interLensMeters = interLensMeters;
        this.trayMeters = trayMeters;
        this.k1 = k1;
        this.k2 = k2;
        this.verticalAlignment = verticalAlignment;
        this.name = name;
        this.source = source;
    }

    public static ViewerProfile defaults() {
        // Cardboard v2 physical values published by Google (manufacturer documentation).
        return new ViewerProfile(.0393f, .0639f, .035f, .33582564f, .55348791f,
                0, "Cardboard v2", "Стандартний профіль (не зчитаний із програми)");
    }

    public static ViewerProfile load(Context context) {
        // Explicit imports are honored first to avoid discarding calibration on every launch.
        String imported = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
                .getString("viewer_url", "");
        if (!imported.isEmpty()) {
            try { return fromUrl(imported); } catch (Exception e) { Log.w("StaticVR", "Invalid saved profile", e); }
        }
        ViewerProfile legacy = loadLegacySharedFile();
        return legacy != null ? legacy : defaults();
    }

    /**
     * Explicitly opt-in only: reads just the Cardboard app's viewer calibration with su.
     * Most recent Google Cardboard SDK versions save this in private app storage.
     * The OS/root manager asks the user to approve elevated access.
     * Must be called on a background thread.
     */
    public static ViewerProfile loadCardboardWithRoot() {
        Process proc = null;
        try {
            // Hard-coded package and path: no user-controlled shell characters.
            proc = new ProcessBuilder("su", "-c",
                    "cat /data/user/0/com.google.samples.apps.cardboarddemo/files/Cardboard/current_device_params")
                    .redirectErrorStream(false).start();
            if (!proc.waitFor(10, TimeUnit.SECONDS) || proc.exitValue() != 0) return null;
            try (InputStream in = proc.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] part = new byte[1024];
                int count;
                while ((count = in.read(part)) != -1) {
                    if (out.size() + count > 65536) return null;
                    out.write(part, 0, count);
                }
                try (DataInputStream data = new DataInputStream(new ByteArrayInputStream(out.toByteArray()))) {
                    return parseDeviceParamsRecord(data,
                            "Автоматично: Google Cardboard (через дозволений root)");
                }
            }
        } catch (Exception e) {
            Log.d("StaticVR", "Root profile not available: " + e.getMessage());
            return null;
        } finally {
            if (proc != null) proc.destroy();
        }
    }

    private static ViewerProfile parseDeviceParamsRecord(DataInputStream input, String source) throws Exception {
        int magic = input.readInt();
        if (magic != 0x35587a2b) return null;
        int size = input.readInt();
        if (size < 8 || size > 16384) return null;
        byte[] data = new byte[size];
        input.readFully(data);
        return decode(data, source);
    }

    public static ViewerProfile loadLegacySharedFile() {
        try {
            File file = new File(Environment.getExternalStorageDirectory(),
                    "Cardboard/current_device_params");
            if (!file.isFile() || file.length() > 65536) return null;
            try (DataInputStream input = new DataInputStream(new FileInputStream(file))) {
                return parseDeviceParamsRecord(input, "Автоматично: Google Cardboard (спільний профіль)");
            }
        } catch (Exception e) {
            Log.d("StaticVR", "No accessible shared Cardboard profile: " + e.getMessage());
            return null;
        }
    }

    public static ViewerProfile fromUrl(String uriText) {
        Uri uri = Uri.parse(uriText.trim());
        String host = uri.getHost();
        if (!"https".equalsIgnoreCase(uri.getScheme()) || host == null ||
                !(host.equalsIgnoreCase("google.com") || host.equalsIgnoreCase("www.google.com"))) {
            throw new IllegalArgumentException("Потрібне https://google.com/cardboard/cfg?p=...");
        }
        if (!"/cardboard/cfg".equals(uri.getPath())) {
            throw new IllegalArgumentException("QR має містити /cardboard/cfg");
        }
        String payload = uri.getQueryParameter("p");
        if (payload == null || payload.length() > 16384) {
            throw new IllegalArgumentException("QR не містить параметр p");
        }
        byte[] bytes = Base64.decode(payload, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
        return decode(bytes, "Імпортовано з QR URL");
    }

    public static ViewerProfile decode(byte[] bytes, String source) {
        if (bytes.length < 8 || bytes.length > 16384) throw new IllegalArgumentException("Некоректний розмір профілю");
        float lens = Float.NaN, ipd = Float.NaN, tray = .035f;
        int alignment = 0;
        String maker = "", model = "";
        List<Float> coefficients = new ArrayList<>();
        int[] offset = {0};
        while (offset[0] < bytes.length) {
            long key = readVarint(bytes, offset);
            int field = (int)(key >> 3);
            int wire = (int)(key & 7);
            if (field == 0) throw new IllegalArgumentException("Невірне поле protobuf");
            if (wire == 0) {
                long value = readVarint(bytes, offset);
                if (field == 11) alignment = (int)value;
            } else if (wire == 5) {
                float f = readFloat(bytes, offset);
                if (field == 3) lens = f;
                else if (field == 4) ipd = f;
                else if (field == 6) tray = f;
                else if (field == 7) coefficients.add(f);
            } else if (wire == 2) {
                int n = (int)readVarint(bytes, offset);
                if (n < 0 || n > bytes.length - offset[0]) throw new IllegalArgumentException("Пошкоджений protobuf");
                int end = offset[0] + n;
                if (field == 7 || field == 5) {
                    if (n % 4 != 0) throw new IllegalArgumentException("Невірні float дані");
                    if (field == 7) while (offset[0] < end) coefficients.add(readFloat(bytes, offset));
                } else if (field == 1 || field == 2) {
                    String str = new String(bytes, offset[0], n, StandardCharsets.UTF_8);
                    if (field == 1) maker = str;
                    else model = str;
                }
                offset[0] = end;
            } else if (wire == 1) {
                skip(bytes, offset, 8);
            } else {
                throw new IllegalArgumentException("Непідтримуваний protobuf тип " + wire);
            }
        }
        if (!Float.isFinite(lens) || !Float.isFinite(ipd) || lens < .01f || lens > .12f ||
                ipd < .03f || ipd > .10f) {
            throw new IllegalArgumentException("Невірні фізичні параметри VR-гарнітури");
        }
        float a = coefficients.size() > 0 ? coefficients.get(0) : 0.33582564f;
        float b = coefficients.size() > 1 ? coefficients.get(1) : 0.55348791f;
        if (!Float.isFinite(a) || !Float.isFinite(b) || Math.abs(a) > 5f || Math.abs(b) > 5f)
            throw new IllegalArgumentException("Неправильні коефіцієнти лінз");
        if (!Float.isFinite(tray) || tray <= 0f) tray = .035f;
        String name = (maker + " " + model).trim();
        if (name.isEmpty()) name = "Cardboard custom";
        return new ViewerProfile(lens, ipd, tray, a, b, alignment, name, source);
    }

    private static long readVarint(byte[] bytes, int[] offset) {
        long result = 0;
        for (int shift = 0; shift < 64; shift += 7) {
            if (offset[0] >= bytes.length) throw new IllegalArgumentException("Обрізаний varint");
            int b = bytes[offset[0]++] & 0xff;
            result |= (long)(b & 127) << shift;
            if ((b & 128) == 0) return result;
        }
        throw new IllegalArgumentException("Завеликий varint");
    }

    private static float readFloat(byte[] bytes, int[] offset) {
        if (offset[0] + 4 > bytes.length) throw new IllegalArgumentException("Обрізаний float");
        float value = ByteBuffer.wrap(bytes, offset[0], 4).order(ByteOrder.LITTLE_ENDIAN).getFloat();
        offset[0] += 4;
        return value;
    }

    private static void skip(byte[] bytes, int[] offset, int length) {
        if (offset[0] + length > bytes.length) throw new IllegalArgumentException("Некоректна довжина");
        offset[0] += length;
    }
}
