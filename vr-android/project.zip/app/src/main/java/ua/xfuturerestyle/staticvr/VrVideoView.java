package ua.xfuturerestyle.staticvr;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * A stationary, native-resolution, two-eye GLES2 video renderer.
 * No sensors are read, so head rotation never moves the video.
 * Both 2D (duplicated) and side-by-side 3D inputs are supported.
 */
public final class VrVideoView extends GLSurfaceView implements GLSurfaceView.Renderer {
    public interface SurfaceReadyListener { void onSurfaceReady(Surface surface); }

    private static final float[] QUAD = {
            -1f, -1f, 0f, 0f,
             1f, -1f, 1f, 0f,
            -1f,  1f, 0f, 1f,
             1f,  1f, 1f, 1f
    };

    private static final String VS =
            "attribute vec2 aPos;\n" +
            "attribute vec2 aUV;\n" +
            "varying vec2 vUV;\n" +
            "void main() { gl_Position = vec4(aPos, 0.0, 1.0); vUV = aUV; }\n";

    private static final String FS =
            "#extension GL_OES_EGL_image_external : require\n" +
            "precision highp float;\n" +
            "uniform samplerExternalOES uTexture;\n" +
            "uniform mat4 uTextureMatrix;\n" +
            "uniform float uK1, uK2, uLensDistance, uInterLens;\n" +
            "uniform float uScreenW, uScreenH, uScreenAspect;\n" +
            "uniform float uMediaAspect, uSbs, uFill, uStrength;\n" +
            "uniform float uVerticalCenter;\n" +
            "varying vec2 vUV;\n" +
            "void main() {\n" +
            "  float eye = step(0.5, vUV.x);\n" +
            "  vec2 uv = vec2((vUV.x - eye * 0.5) * 2.0, vUV.y);\n" +
            "  float lensLeft = clamp(1.0 - uInterLens / max(uScreenW, 0.05), 0.30, 0.70);\n" +
            "  vec2 center = vec2(mix(lensLeft, 1.0 - lensLeft, eye), uVerticalCenter);\n" +
            "  vec2 d = uv - center;\n" +
            "  vec2 t = vec2(d.x * uScreenW * 0.5, d.y * uScreenH) / max(uLensDistance, 0.015);\n" +
            "  float r2 = dot(t, t);\n" +
            "  float dx = max(center.x, 1.0 - center.x) * uScreenW * 0.5 / max(uLensDistance, 0.015);\n" +
            "  float dy = max(center.y, 1.0 - center.y) * uScreenH / max(uLensDistance, 0.015);\n" +
            "  float maxR2 = dx * dx + dy * dy;\n" +
            "  float f = 1.0 + uStrength * (uK1 * r2 + uK2 * r2 * r2);\n" +
            "  float maxF = max(0.1, 1.0 + uStrength * (uK1 * maxR2 + uK2 * maxR2 * maxR2));\n" +
            "  vec2 correct = center + d * (f / maxF);\n" +
            "  float eyeAspect = uScreenAspect * 0.5;\n" +
            "  float inputAspect = max(0.1, uMediaAspect / mix(1.0, 2.0, uSbs));\n" +
            "  vec2 sampled = correct;\n" +
            "  if (uFill > 0.5) {\n" +
            "    if (inputAspect > eyeAspect) sampled.x = 0.5 + (sampled.x - 0.5) * (eyeAspect / inputAspect);\n" +
            "    else sampled.y = 0.5 + (sampled.y - 0.5) * (inputAspect / eyeAspect);\n" +
            "  } else {\n" +
            "    if (inputAspect > eyeAspect) sampled.y = 0.5 + (sampled.y - 0.5) * (inputAspect / eyeAspect);\n" +
            "    else sampled.x = 0.5 + (sampled.x - 0.5) * (eyeAspect / inputAspect);\n" +
            "    if (sampled.x < 0.0 || sampled.x > 1.0 || sampled.y < 0.0 || sampled.y > 1.0) {\n" +
            "      gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0); return;\n" +
            "    }\n" +
            "  }\n" +
            "  sampled = clamp(sampled, vec2(0.001), vec2(0.999));\n" +
            "  if (uSbs > 0.5) sampled.x = 0.5 * (sampled.x + eye);\n" +
            "  vec4 videoUV = uTextureMatrix * vec4(sampled, 0.0, 1.0);\n" +
            "  gl_FragColor = texture2D(uTexture, videoUV.xy);\n" +
            "}\n";

    private final FloatBuffer vertices;
    private final float[] transform = new float[16];
    private final Object frameLock = new Object();
    private SurfaceTexture surfaceTexture;
    private Surface surface;
    private boolean frameAvailable;
    private int textureId;
    private int program;
    private int screenWidth = 1, screenHeight = 1;
    private volatile int videoWidth = 1920, videoHeight = 1080;
    private volatile float pixelRatio = 1f;
    private volatile boolean sideBySide = false, fillScreen = true;
    private volatile float strength = 1f;
    private volatile ViewerProfile profile = ViewerProfile.defaults();
    private volatile SurfaceReadyListener surfaceListener;

    private int posAttr, uvAttr, texMatrixUniform, texUniform;
    private int k1Uniform, k2Uniform, distanceUniform, ipdUniform, screenWUniform,
            screenHUniform, aspectUniform, videoAspectUniform, sbsUniform, fillUniform,
            strengthUniform, verticalUniform;

    public VrVideoView(Context context) {
        super(context);
        vertices = ByteBuffer.allocateDirect(QUAD.length * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer();
        vertices.put(QUAD).position(0);
        setEGLContextClientVersion(2);
        setPreserveEGLContextOnPause(true);
        setRenderer(this);
        setRenderMode(RENDERMODE_WHEN_DIRTY);
        Matrix.setIdentityM(transform, 0);
    }

    public void setSurfaceReadyListener(SurfaceReadyListener listener) {
        this.surfaceListener = listener;
        if (surface != null && listener != null) post(() -> listener.onSurfaceReady(surface));
    }

    public void setViewerProfile(ViewerProfile profile) { this.profile = profile; requestRender(); }
    public void setInputIsSbs(boolean value) { sideBySide = value; requestRender(); }
    public void setFillScreen(boolean value) { fillScreen = value; requestRender(); }
    public void setDistortionStrength(float value) { strength = value; requestRender(); }
    public void setVideoSize(int width, int height, float ratio) {
        if (width > 0 && height > 0) {
            videoWidth = width;
            videoHeight = height;
            pixelRatio = ratio > 0f ? ratio : 1f;
            requestRender();
        }
    }

    @Override public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        program = link(compile(GLES20.GL_VERTEX_SHADER, VS), compile(GLES20.GL_FRAGMENT_SHADER, FS));
        posAttr = GLES20.glGetAttribLocation(program, "aPos");
        uvAttr = GLES20.glGetAttribLocation(program, "aUV");
        texMatrixUniform = GLES20.glGetUniformLocation(program, "uTextureMatrix");
        texUniform = GLES20.glGetUniformLocation(program, "uTexture");
        k1Uniform = GLES20.glGetUniformLocation(program, "uK1");
        k2Uniform = GLES20.glGetUniformLocation(program, "uK2");
        distanceUniform = GLES20.glGetUniformLocation(program, "uLensDistance");
        ipdUniform = GLES20.glGetUniformLocation(program, "uInterLens");
        screenWUniform = GLES20.glGetUniformLocation(program, "uScreenW");
        screenHUniform = GLES20.glGetUniformLocation(program, "uScreenH");
        aspectUniform = GLES20.glGetUniformLocation(program, "uScreenAspect");
        videoAspectUniform = GLES20.glGetUniformLocation(program, "uMediaAspect");
        sbsUniform = GLES20.glGetUniformLocation(program, "uSbs");
        fillUniform = GLES20.glGetUniformLocation(program, "uFill");
        strengthUniform = GLES20.glGetUniformLocation(program, "uStrength");
        verticalUniform = GLES20.glGetUniformLocation(program, "uVerticalCenter");

        int[] textures = new int[1];
        GLES20.glGenTextures(1, textures, 0);
        textureId = textures[0];
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);

        SurfaceTexture oldTexture = surfaceTexture;
        Surface oldSurface = surface;
        surfaceTexture = new SurfaceTexture(textureId);
        surface = new Surface(surfaceTexture);
        surfaceTexture.setOnFrameAvailableListener(texture -> {
            synchronized (frameLock) { frameAvailable = true; }
            requestRender();
        });
        if (oldSurface != null) oldSurface.release();
        if (oldTexture != null) oldTexture.release();
        SurfaceReadyListener listener = surfaceListener;
        if (listener != null) post(() -> listener.onSurfaceReady(surface));
        GLES20.glClearColor(0f, 0f, 0f, 1f);
        requestRender();
    }

    @Override public void onSurfaceChanged(GL10 gl, int width, int height) {
        screenWidth = Math.max(1, width);
        screenHeight = Math.max(1, height);
        GLES20.glViewport(0, 0, screenWidth, screenHeight);
    }

    @Override public void onDrawFrame(GL10 gl) {
        GLES20.glViewport(0, 0, screenWidth, screenHeight);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        if (surfaceTexture == null) return;
        synchronized (frameLock) {
            if (frameAvailable) {
                try {
                    surfaceTexture.updateTexImage();
                    surfaceTexture.getTransformMatrix(transform);
                } catch (RuntimeException e) {
                    Log.w("StaticVR", "Video texture unavailable", e);
                }
                frameAvailable = false;
            }
        }

        ViewerProfile p = profile;
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        // DisplayMetrics.xdpi/ydpi can be inaccurate on some devices; clamp to plausible sizes.
        float wMeters = screenWidth / Math.max(120f, metrics.xdpi) * .0254f;
        float hMeters = screenHeight / Math.max(120f, metrics.ydpi) * .0254f;
        float centerY = .5f;
        if (p.verticalAlignment == 0 && hMeters > .04f)
            centerY = clamp(p.trayMeters / hMeters, .40f, .60f);
        else if (p.verticalAlignment == 2 && hMeters > .04f)
            centerY = clamp(1f - p.trayMeters / hMeters, .40f, .60f);

        GLES20.glUseProgram(program);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId);
        GLES20.glUniform1i(texUniform, 0);
        GLES20.glUniformMatrix4fv(texMatrixUniform, 1, false, transform, 0);
        GLES20.glUniform1f(k1Uniform, p.k1);
        GLES20.glUniform1f(k2Uniform, p.k2);
        GLES20.glUniform1f(distanceUniform, p.screenToLensMeters);
        GLES20.glUniform1f(ipdUniform, p.interLensMeters);
        GLES20.glUniform1f(screenWUniform, wMeters);
        GLES20.glUniform1f(screenHUniform, hMeters);
        GLES20.glUniform1f(aspectUniform, (float)screenWidth / screenHeight);
        GLES20.glUniform1f(videoAspectUniform, videoWidth * pixelRatio / (float)videoHeight);
        GLES20.glUniform1f(sbsUniform, sideBySide ? 1f : 0f);
        GLES20.glUniform1f(fillUniform, fillScreen ? 1f : 0f);
        GLES20.glUniform1f(strengthUniform, strength);
        GLES20.glUniform1f(verticalUniform, centerY);

        vertices.position(0);
        GLES20.glEnableVertexAttribArray(posAttr);
        GLES20.glVertexAttribPointer(posAttr, 2, GLES20.GL_FLOAT, false, 16, vertices);
        vertices.position(2);
        GLES20.glEnableVertexAttribArray(uvAttr);
        GLES20.glVertexAttribPointer(uvAttr, 2, GLES20.GL_FLOAT, false, 16, vertices);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        GLES20.glDisableVertexAttribArray(posAttr);
        GLES20.glDisableVertexAttribArray(uvAttr);
    }

    private static float clamp(float x, float a, float b) { return Math.max(a, Math.min(b, x)); }

    private static int compile(int type, String source) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, source);
        GLES20.glCompileShader(shader);
        int[] ok = new int[1];
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) {
            String message = GLES20.glGetShaderInfoLog(shader);
            GLES20.glDeleteShader(shader);
            throw new IllegalStateException("GL shader compile failed: " + message);
        }
        return shader;
    }

    private static int link(int vertex, int fragment) {
        int program = GLES20.glCreateProgram();
        GLES20.glAttachShader(program, vertex);
        GLES20.glAttachShader(program, fragment);
        GLES20.glLinkProgram(program);
        int[] ok = new int[1];
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) throw new IllegalStateException("GL program link failed: " + GLES20.glGetProgramInfoLog(program));
        GLES20.glDeleteShader(vertex);
        GLES20.glDeleteShader(fragment);
        return program;
    }
}
